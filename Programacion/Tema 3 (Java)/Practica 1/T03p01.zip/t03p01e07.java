import java.util.Scanner;
public class t03p01e07{

	public static void main (String[] args){
	
			
		int num1;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Introduce un numero: ");
		num1 = sc.nextInt();
		
		for (int i=1; i<=num1; i++){
			System.out.printf("%d",i);
		}

}
 
}
