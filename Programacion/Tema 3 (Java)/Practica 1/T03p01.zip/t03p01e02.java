import java.util.Scanner;
import java.lang.Math;

public class t03p01e02 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int x;
		int z;
		
		System.out.println("Introduce un numero: ");
		x=sc.nextInt();
		System.out.println("Introduce otro numero: ");
		z=sc.nextInt();

		if(x==z){
			
			System.out.println(" Son los numereos iguales : ");

		} else {
			
			System.out.println(" No son iguales: ");

		}
			
	
	}
}
