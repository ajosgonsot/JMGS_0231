import java.util.Scanner;

public class T03p04e05 {

public static void main (String[] args) {
				

	for( int i=100; i>0; i-=7) {
		
		System.out.println(""+i);
		
		}
	

	}
}
