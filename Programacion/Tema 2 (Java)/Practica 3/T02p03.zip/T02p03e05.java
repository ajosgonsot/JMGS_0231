import java.util.Scanner;
public class T02p03e05 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		
		float pi=3.1415F;
		float radio=3;		
		float circuferencia=5.2F;
		float resultado;
		float resultado2;
		
		resultado=2*pi*radio;
		
		System.out.println("La longitud de un circuferencia es :"+resultado);
		
		resultado2=pi*(circuferencia*circuferencia);
		
		System.out.println("El area de la circuferencia es :"+resultado2);
		
		
		
		
		
		
	}
}
