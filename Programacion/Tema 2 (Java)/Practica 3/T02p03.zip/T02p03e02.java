import java.util.Scanner;

public class T02p03e02 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);

		
		System.out.printf("Introduce una letra: ");
		char letra=sc.next().charAt(0);
		
		System.out.printf("letra mayuscula es: %c",letra-32);
		
		
		



	}
}
