public class T02p04e05 {
	
	public static void main (String[] args) {
		
		int t= 130;
		
		System.out.println("El tiempo en horas es: "+t/3600F);
		System.out.println("El tiempo en minutos es: "+t/60F);
		System.out.println("El tiempo en segundos es: "+t);
		
		System.out.println("El tiempo es: " +t/3600F + "horas " + t/60 + "min y " +t + "seg");
		
	
	}
	
}
