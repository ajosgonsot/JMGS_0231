public class T02p04e02 {
	
	public static void main (String[] args) {
		
	System.out.printf("El precio final es: "+(85*85)/100F);
	
	}
	
}
