public class T02p04e04 {
	
	public static void main (String[] args) {
		
	float pi=3.1415F;
	float diametro=15.5F;
	float radio=7.75F;
	float altura=42.40F;

	System.out.printf("Para un cilindro de radio 7,75 y altura 42,40\n");
	System.out.printf("El area es: "+(2*pi*(radio*radio)+2*pi*radio*altura)+"\n");
	System.out.printf("El volumen es: "+(pi*(radio*radio)*altura));
	

		}

	}
