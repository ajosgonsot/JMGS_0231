public class T02p04e03 {
	
	public static void main (String[] args) {
		
	System.out.println("Calculo de intereses.");
	System.out.println("Dinero ingresado: 2000e");
	System.out.println("Interes anual: 2.75%");
	System.out.println("Interes a los seis meses: "+(2000*2.75/100)*6/12);
	System.out.println("Retenciones realizadas: "+27.5*82/100);
	
	
	}

}
