package test;

import modelo.Alumno;
import modelo.Profesor;

public class Test {

    public static void main(String[] args) {

        Alumno[] listaAlumnos = new Alumno[10];

        Alumno a = new Alumno();
        a.setDni("1");
        a.setNombre("pepe");
        a.getDireccion().setCalle("Calle 1");
        a.getDireccion().setCiudad("Ciudad 1");
        System.out.println("Dni: " + a.getDni() + " Nombre: " + a.getNombre()
                + " Calle: " + a.getDireccion().getCalle() + " Ciudad: "
                + a.getDireccion().getCiudad());

        Alumno b = new Alumno("2");
        b.setNombre("Manolo");
        System.out.println("DNI: " + b.getDni() + " Nombre: " + b.getNombre());

        //listaAlumnos[0] = a;
        //listaAlumnos[1] = b;
        a.altaAlumno(listaAlumnos);
        b.altaAlumno(listaAlumnos, 1);

        for (int i = 0; i < 10; i++) {
            if (listaAlumnos[i] != null) {
                System.out.println("DNI: "
                        + listaAlumnos[i].getDni()
                        + " NOMBRE: " + listaAlumnos[i].getNombre());
            }
        }

        Profesor p = new Profesor();

        p.setDni("3");
        p.setNombre("Paco");
        p.setAlumno(a);

        System.out.println("Dni: " + p.getDni() + " Nombre: " + p.getNombre()
                + " Alumno: " + p.getAlumno().getDni() + " " + p.getAlumno().getNombre());
    }

}
