package modelo;

public class Profesor {

    private String dni;
    private String nombre;
    private Alumno alumno;

    public Profesor() {
        dni = "";
        nombre = "";
        alumno=null;
    }

    public Profesor(String dni) {
        this.dni = dni;
        this.nombre = "";
        this.alumno=null;

    }

    public void setDni(String dni) { 
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public Alumno getAlumno() {
        return alumno;
    }

}
