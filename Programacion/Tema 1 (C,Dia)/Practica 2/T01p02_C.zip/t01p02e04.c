#include<stdio.h>
#include<stdlib.h>

int main() {
	
	char letra;
	int contador=0;
	
	for (int contador=0; contador<10; contador=contador+2) {
	
	printf("introduce un caracter: ");
	scanf(" %c",&letra);
	printf("El caracter es: %c\n",letra);	
	
	
	
	
	
	
	
	}
	
	system("pause");
	return 0;	
}