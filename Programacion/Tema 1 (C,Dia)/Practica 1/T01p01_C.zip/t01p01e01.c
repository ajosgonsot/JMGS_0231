#include<stdio.h>
#include<stdlib.h>

int main()  {

	int num1=0;
	int num2=0;
	
	printf ("num1 vale: %i\n",num1);
	printf ("num2 vale: %i\n",num2);
	


	system("pause");
	return 0;	
}