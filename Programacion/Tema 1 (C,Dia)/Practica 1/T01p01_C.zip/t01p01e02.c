#include <stdio.h>
#include <stdlib.h>

int main () {

	
		float num1;
		float num2;
		const float pi=3.1415;
		float multiplicacion;
		
		
		printf ("Introduce el numero: ");
		scanf ("%f",&num1);
		printf ("Introduce el numero: ");
		scanf ("%f",&num2);
		
		multiplicacion=num1*num2*pi;
		
		printf ("El resultado es %f\n",multiplicacion);
		
		
	
	
	
	
	
	
	
	system("pause");
	return 0;	
}