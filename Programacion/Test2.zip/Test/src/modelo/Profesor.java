package modelo;

public class Profesor {

    private String dni;
    private String nombre;
    private Alumno[] alumnos;

    public Profesor() {
        dni = "";
        nombre = "";
        alumnos = new Alumno[10];
    }

    public Profesor(String dni) {
        this.dni = dni;
        this.nombre = "";
        this.alumnos = new Alumno [10];

    }

    public void setDni(String dni) { 
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAlumnos(Alumno[] alumnos) {
        this.alumnos = alumnos;
    }

    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public Alumno[] getAlumnos() {
        return alumnos;
    }

}
