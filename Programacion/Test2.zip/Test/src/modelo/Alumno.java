package modelo;

public class Alumno {

    private String dni;
    private String nombre;
    private Direccion direccion;

    public Alumno() {
        dni = "";
        nombre = "";
        direccion = new Direccion();
    }

    public Alumno(String dni) {
        this.dni = dni;
        this.nombre = "";
        this.direccion = new Direccion();
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean altaAlumno(Alumno[] tAlumnos) {
        tAlumnos[0] = this;
        return true;
    }

    public boolean altaAlumno(Alumno[] tAlumnos, int pos) {
        tAlumnos[pos] = this;
        return true;
    }
    
    public class Direccion {
        private String calle;
        private String ciudad;

        public String getCalle() {
            return calle;
        }

        public void setCalle(String calle) {
            this.calle = calle;
        }

        public String getCiudad() {
            return ciudad;
        }

        public void setCiudad(String ciudad) {
            this.ciudad = ciudad;
        }
        
    }
    
}
