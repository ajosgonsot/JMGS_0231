import java.util.*;

public class T04p01ej01 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int[] t=new int[5];
		
		System.out.println("");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}

		System.out.println("");
		System.out.println("Los numeros en orden inverso son: ");
		
		for (int i=t.length-1; i>=0; i--) {
			System.out.print(t[i]+" ");
		}

		System.out.println("");
	}
	
}
