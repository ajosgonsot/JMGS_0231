import java.util.*;

public class T04p01ej02 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int[] t=new int[5];
		int acum=0;
		
		System.out.println("");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}

		for (int i=0; i<t.length; i++) {
			acum=acum+t[i];
		}

		System.out.println("");
		System.out.println("La suma acumulada de todos los numeros es: ");
		System.out.println(acum);
		
		System.out.println("");
	}
	
}
