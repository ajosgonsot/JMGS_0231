import java.util.*;

public class T04p01ej03 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int[] t=new int[5];
		int cantPares=0;
		
		System.out.println("");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}

		for (int i=0; i<t.length; i++) {
			if (t[i]%2==0) {
				cantPares++;
			}
		}

		System.out.println("");
		System.out.println("La cantidad de numeros pares introducidos es: ");
		System.out.println(cantPares);
		
		System.out.println("");
	}
	
}
