import java.util.*;

public class T04p01ej05 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		final int CAPACIDAD=3;
		int[] t1=new int[CAPACIDAD];
		int[] t2=new int[CAPACIDAD];
		int[] t3=new int[CAPACIDAD*2];
		
		System.out.println("");
		System.out.println("Leyendo array 1...");
		for (int i=0; i<t1.length; i++) {
			System.out.print("Introduzca un numero: ");
			t1[i]=sc.nextInt();
		}

		System.out.println("");
		System.out.println("Leyendo array 2...");
		for (int i=0; i<t2.length; i++) {
			System.out.print("Introduzca un numero: ");
			t2[i]=sc.nextInt();
		}
		
		int k=0;
		for (int j=0; j<CAPACIDAD; j++) {
			t3[k]=t1[j];
			k++;
			t3[k]=t2[j];
			k++;
		}
		
		System.out.println("");
		System.out.println("El array 1 es: ");
		for (int i=0; i<t1.length; i++)
			System.out.print(t1[i]+" ");
		System.out.println("");
		System.out.println("El array 2 es: ");
		for (int i=0; i<t2.length; i++)
			System.out.print(t2[i]+" ");
		System.out.println("");
		System.out.println("El array 3 es: ");
		for (int i=0; i<t3.length; i++)
			System.out.print(t3[i]+" ");

		System.out.println("");
	}
	
}
