import java.util.*;

public class T04p01ej04 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int[] t=new int[5];
		boolean esCreciente=true;
		
		System.out.println("");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}

		for (int i=0; i<t.length-1; i++) {
			if (t[i]>t[i+1]) {
				esCreciente=false;
				break;
			}
		}

		System.out.println("");
		if (esCreciente) {
			System.out.println("La serie de numeros introducidos es creciente.");
		} else {
			System.out.println("La serie de numeros introducidos no es creciente.");
		}
		
		System.out.println("");
	}
	
}
