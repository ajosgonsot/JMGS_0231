import java.util.*;

public class T04p03ej01 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		final int CAPACIDAD=5;
		int[] t=new int[CAPACIDAD];
		int key;
		int pos=-1;
		
		System.out.println("");
		System.out.println("Leyendo datos...");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}
		
		System.out.println("");
		System.out.println("El array introducido es:");
		for (int i=0; i<t.length; i++) {
			System.out.print(t[i]+" ");
		}

		System.out.println("");
		System.out.println("");
		System.out.print("Introduzca el numero a buscar: ");
		key=sc.nextInt();

		for (int i=0; i<t.length; i++) {
			if (t[i]==key) {
				pos=i;
				break;
			}
		}

		if (pos!=-1) {
			System.out.println("Numero "+key+" en posicion "+pos);
		} else {
			System.out.println("Numero "+key+ " no existe!!");
		}

		System.out.println("");
	}
	
}
