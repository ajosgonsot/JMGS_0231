import java.util.*;

public class T04p03ej04 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		final int CAPACIDAD=5;
		int[] t=new int[CAPACIDAD];
		int key;
		int pos=-1;
		
		System.out.println("");
		System.out.println("Leyendo datos...");
		for (int i=0; i<t.length; i++) {
			System.out.print("Introduzca un numero: ");
			t[i]=sc.nextInt();
		}
		
		System.out.println("");
		System.out.println("El array introducido es:");
		for (int i=0; i<t.length; i++) {
			System.out.print(t[i]+" ");
		}

		System.out.println("");
		System.out.println("");
		System.out.print("Introduzca la posicion (0..4) del numero a borrar: ");
		pos=sc.nextInt();

		for (int i=pos; i<t.length-1; i++) {
			t[i]=t[i+1];
		}
		t[t.length-1]=0;

		System.out.println("");
		System.out.println("El array resultado es:");
		for (int i=0; i<t.length; i++) {
			System.out.print(t[i]+" ");
		}

		System.out.println("");
	}
	
}
