import java.util.*;

public class T04p01ej06 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);

		final int CAPACIDAD=3;
		final int NUMEXAMENES=3;
		int[] ex1=new int[CAPACIDAD];
		int[] ex2=new int[CAPACIDAD];
		int[] ex3=new int[CAPACIDAD];
		int[] sumasPorAlumno=new int[CAPACIDAD];
		
		int sumaEx1=0, sumaEx2=0, sumaEx3=0;

		System.out.println("");
		System.out.println("Leyendo notas 1er examen...");
		for (int i=0; i<ex1.length; i++) {
			System.out.print("Alumno ("+(i+1)+"): ");
			ex1[i]=sc.nextInt();
		}

		System.out.println("");
		System.out.println("Leyendo notas 2o examen...");
		for (int i=0; i<ex2.length; i++) {
			System.out.print("Alumno ("+(i+1)+"): ");
			ex2[i]=sc.nextInt();
		}

		System.out.println("");
		System.out.println("Leyendo notas 3er examen...");
		for (int i=0; i<ex3.length; i++) {
			System.out.print("Alumno ("+(i+1)+"): ");
			ex3[i]=sc.nextInt();
		}

		for (int i=0; i<CAPACIDAD; i++) {
			sumaEx1=sumaEx1+ex1[i];
			sumaEx2=sumaEx2+ex2[i];
			sumaEx3=sumaEx3+ex3[i];
			sumasPorAlumno[i]=ex1[i]+ex2[i]+ex3[i];
		}
		
		System.out.println("");
		System.out.printf("Media primer examen: %.2f\n",(double)sumaEx1/CAPACIDAD);
		System.out.printf("Media segundo examen: %.2f\n",(double)sumaEx2/CAPACIDAD);
		System.out.printf("Media tercer examen: %.2f\n",(double)sumaEx3/CAPACIDAD);

		System.out.println("");
		for (int i=0; i<CAPACIDAD; i++) {
			System.out.printf("Media del alumno %d es: %.2f\n",i+1,(double)sumasPorAlumno[i]/CAPACIDAD);
		}
		
		System.out.println("");
	}
	
}
