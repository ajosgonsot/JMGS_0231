import java.util.*;

public class T04p03ej06 {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		final int CAPACIDAD=5;
		int[] t1=new int[CAPACIDAD];
		int[] t2=new int[CAPACIDAD];
		int min=0;
		int pos=0;
		int j=0;
		
		System.out.println("");
		System.out.println("Leyendo datos...");
		for (int i=0; i<t1.length; i++) {
			System.out.print("Introduzca un numero: ");
			t1[i]=sc.nextInt();
		}
		
		System.out.println("");
		System.out.println("El array introducido es:");
		for (int i=0; i<t1.length; i++) {
			System.out.print(t1[i]+" ");
		}


		do {
			min=0;
			// Supongo que el primer número distinto de cero es el mínimo
			for (int i=0; i<t1.length; i++) {
				if (t1[i]!=0) {
					min=t1[i];
					pos=i;
					break;
				}
			}
			if (min!=0) {
				// Busco el mínimo
				for (int i=0; i<t1.length; i++) {
					if (t1[i]!=0 && t1[i]<min) {
						min=t1[i];
						pos=i;
					}
				}
				t1[pos]=0;
				t2[j++]=min;
			}
		} while (min!=0);


		System.out.println("");
		System.out.println("");
		System.out.println("El array resultado es:");
		for (int i=0; i<t2.length; i++) {
			System.out.print(t2[i]+" ");
		}

		System.out.println("");
	}
	
}
