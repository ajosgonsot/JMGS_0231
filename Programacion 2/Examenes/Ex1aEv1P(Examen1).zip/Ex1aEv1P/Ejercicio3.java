import java.util.Scanner;
public class Ejercicio3 {

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		final int aleatorio;
		int intentos, contador=0, numero, contador2=0;
		
		aleatorio = (int)(Math.random()*10+1);
		
		System.out.println("Adivina el numero aleatorio entre 1 y 10");
		System.out.print("Introduce la cantidad maxima de intentos: ");
		intentos = sc.nextInt();
		
		System.out.println();
		
		do {
			
			System.out.println();
			
			do{
				
				System.out.print("Introduce un numero (1-10): ");
				numero = sc.nextInt();
				
			}while(numero<1 || numero>10);
			
			contador++;
			
			
			System.out.println();
			
			if (numero>aleatorio) {
				
				System.out.println("Lo siento, intentalo de nuevo!!");
				System.out.println("Pista: Es numero a adivinar es menor.");
				contador2++;
			
			} else if (numero<aleatorio) {
				
				System.out.println("Lo siento, intentalo de nuevo!!");
				System.out.println("Pista: Es numero a adivinar es mayor.");
				contador2++;
				
			}else if (numero==aleatorio) {
				contador2++;
				System.out.print("Acertaste!! El numero generado es: "+aleatorio+" (num. de intentos "+contador2+").");
				break;
				
			}
			
			if(contador==intentos) {
				System.out.println();
				System.out.println("No Acertaste!! Sobrepasaste el numero de intentos!!");
			}
			
		}while(contador<intentos);
		
	}

}
