import java.util.Scanner;
public class Ejercicio5 {
	
	private static int mostrarMenu() {
		Scanner sc = new Scanner(System.in);
		
		int op;
		
		System.out.println(" Menu ");
		System.out.println(" --- ");
		System.out.println("1. - Redondeo (por debajo) de un numero decimal (con Math). ");
		System.out.println("2. - Potencia de dos numeros enteros (con Math). ");
		System.out.println("3. - Averiguar si un numero entero es primo (sin Math) ");
		System.out.println("0. - Salir ");
		System.out.print("Opcion?  ");
		op = sc.nextInt();
	
	
		return op;
	
	
	}
	
	
	private static String esPrimo(int numero2) {
		int divisores;
		String texto;
		divisores=0;					
		for (int i=1; i<=numero2; i++) {
			
			if(numero2%i==0) {
				divisores++;
			}
			
		}
		
		if (divisores==2) {
			texto="primo";
		}else {
			texto="no es primo";
		}
		
		return texto;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int op;
		
		
		do {
			
			op=mostrarMenu();
			
			switch (op) {
				
				case 0:
					break;
				case 1:
					
					double numero1, resultado;
				
					System.out.print("Introduce un numero: ");
					numero1 = sc.nextDouble();
					
					resultado = Math.floor(numero1);
					
					System.out.printf("El resultado es: %.2f\n",resultado);
				
					break;
				case 2:
				
					int base, exponente, resultado1;
					
					System.out.print("Introduce un numero: ");
					base = sc.nextInt();
					
					System.out.print("Introduce otro numero: ");
					exponente = sc.nextInt();
				
					resultado1 = (int)(Math.pow(base,exponente));
						
					System.out.println("El resultado es: "+resultado1);	
					
					break;
				case 3:
				
					int numero2;
					String texto;
					System.out.print("Introduce un numero: ");
					numero2 = sc.nextInt();
					
					texto = esPrimo(numero2);
					
					System.out.println("El resultado es: "+texto);
					
				
					break;
				
				default:
					System.out.println("Opcion Incorrecta!!");
			
			}
			
		}while (op!=0);
		
	
	}
}
