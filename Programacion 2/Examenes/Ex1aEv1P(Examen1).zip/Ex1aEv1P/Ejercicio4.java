import java.util.Scanner;

public class Ejercicio4 {

	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int numero, primero, segundo, tercero, temporal, total;
		int aleaPrimero, contadorPrimero=0;
		int aleaSegundo, contadorSegundo=0;
		int aleaTercero, contadorTercero=0;
		float porcA, porcB, porcC;
		
		do {
			
			System.out.print("Introduce un numero entre 111 y 555: ");
			numero = sc.nextInt();
			
			temporal=numero;
			primero = temporal/100;
			temporal = temporal%100;
			segundo = temporal/10;
			temporal = temporal%10;
			tercero = temporal/1;
			temporal = temporal%1;
			
			System.out.println("Primero: "+primero+" Segundo: "+segundo+" Tercero: "+tercero);
			
			
			do{
				
				aleaPrimero = (int)(Math.random()*(5-1+1)+1);
				System.out.print(aleaPrimero+" ");
				if(aleaPrimero==primero) {
					
					System.out.println("Tengo el primero");
				}
				contadorPrimero++;
				
			}while(aleaPrimero!=primero);
			
			
			do{
				
				aleaSegundo = (int)(Math.random()*(5-1+1)+1);
				System.out.print(aleaSegundo+" ");
				if(aleaSegundo==segundo) {
					
					System.out.println("Tengo el segundo");
				}
				contadorSegundo++;
				
			}while(aleaSegundo!=segundo);
			
			
			do{
				
				aleaTercero = (int)(Math.random()*(5-1+1)+1);
				System.out.print(aleaTercero+" ");
				if(aleaTercero==tercero) {
					
					System.out.println("Tengo el tercero");
				}
				contadorTercero++;
				
			}while(aleaTercero!=tercero);
			
					
		
		}while(numero<111 || numero>555);
		
		total = contadorPrimero+contadorSegundo+contadorTercero;
		
		porcA = (float)((contadorPrimero*100)/total);
		
		porcB = (float)((contadorSegundo*100)/total);
		
		porcC = (float)((contadorTercero*100)/total);
		
		
		System.out.println();
		System.out.println("El numero es:-) "+numero);
		System.out.println("Intentos    : "+contadorPrimero+" para las centenas, "+contadorSegundo+" para decenas y "+contadorTercero+" para las unidades!!");
		System.out.printf("Intentos (%%): %.2f para centenas, %.2f para decenas y %.2f para unidades!!",porcA,porcB,porcC);
		
		
		
		
		
		
		
		

	}



}
