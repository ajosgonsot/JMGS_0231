import java.util.Scanner;

public class GestionHotel {

    private static int mostrarMenu() {

        Scanner sc=new Scanner(System.in);
        int op;
        System.out.println("\tMENU");
        System.out.println("\t----");
        System.out.println("\t");
        System.out.println("\t1.- Listado de Clientes.");
        System.out.println("\t2.- Alta de Habitacion.");
        System.out.println("\t3.- Baja de Habitacion.");
        System.out.println("\t4.- Listado de Habitaciones.");
        System.out.println("\t5.- Alta de Reserva.");
        System.out.println("\t6.- Baja de Reserva (Anular/Facturar).");
        System.out.println("\t7.- Listado de Reservas.");
        System.out.println("\t0.- Salir.");
        System.out.println("\t");
        System.out.print("\tOpcion? ");
        op = sc.nextInt();
        System.out.println("\t");
        return op;
    }
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int op;


        do {
            System.out.println("\t");
            op=mostrarMenu();
            
            switch (op) {
				
                case 1: // Listado de Clientes

                    System.out.println("\tLISTADO DE CLIENTES");
                    System.out.println("\t-------------------\n");
                    break;
                
                case 2: // Alta de Habitacion

						System.out.println("\tTabla de Habitaciones completa!!");
						System.out.print("\tIntroduce id de Habitacion: ");
						System.out.print("\tIntroduce descripcion de Habitacion: ");
						System.out.print("\tIntroduce tipo (0:NULL,1:SIMPLE,2:DOBLE,3:OTRO) de Habitacion: ");
						System.out.print("\tIntroduce precio de Habitacion: ");
						System.out.println("\t");
						
							System.out.println("\tAlta de Habitacion correcta.");
							System.out.println("\tAlta de Habitacion incorrecta!!");
					break;
                
                case 3: // Baja de Habitacion

						System.out.println("\tTabla de Habitaciones vacia!!");
						System.out.print("\tIntroduce id de Habitacion: ");
						System.out.println("\t");
						
							System.out.println("\tBaja de Habitacion correcta.");
							System.out.println("\tBaja de Habitacion incorrecta!!");
					break;
                
                case 4: // Listado de Habitaciones

                    System.out.println("\tLISTADO DE HABITACIONES");
                    System.out.println("\t-----------------------\n");
                    break;
                
                case 5: // Alta de Reserva

						System.out.println("\tTabla de Reservas completa!!");
						System.out.print("\tIntroduce dni Cliente de Reserva: ");
						System.out.print("\tIntroduce id Habitacion de Reserva: ");
						System.out.print("\tIntroduce fecha Ini (dd/mm/yyyy) de Reserva: ");
						System.out.println("\t");
						
							System.out.println("\tAlta de Reserva correcta.");
							System.out.println("\tAlta de Reserva incorrecta!!");
					break;
                
                case 6: // Baja de Reserva

						System.out.println("\tTabla de Reservas vacia!!");
						System.out.print("\tIntroduce dni Cliente de Reserva: ");
						System.out.print("\tIntroduce id Habitacion de Reserva: ");
						System.out.print("\tIntroduce fec Ini (dd/mm/yyyy) de Reserva: ");
						System.out.println("\t");
						
							System.out.println("\tBaja de Reserva correcta.");
							System.out.println("\tBaja de Reserva incorrecta!!");
					break;
                
                case 7: // Listado de Reservas

                    System.out.println("\tLISTADO DE RESERVAS");
                    System.out.println("\t-------------------\n");
                    break;
                                   
                case 0: // Salir
                    break;
                
                default:
                    System.out.println("\tOpción incorrecta!!");
                    System.out.println("\t");
            }
            
        } while (op!=0);
        System.out.println("\t");
        
    }

}
