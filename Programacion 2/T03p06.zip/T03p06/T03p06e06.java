import java.util.Scanner;
public class T03p06e06 {
	
	private static int suma(int num1, int num2){
		int suma;
		suma = num1+num2;
		return suma;
	}
	
	private static int resta(int num1, int num2){
		int resta;
		resta = num1-num2;
		return resta;
	}
	
	private static int multiplicacion(int num1, int num2){
		int multiplicacion;
		multiplicacion=num1*num2;
		return multiplicacion;
	}
	
	private static float division(int num1, int num2){
		float division;
		division=(float)num1/num2;
		return division;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		
		int num1,num2;
		int suma,resta,multiplicacion;
		float division; 
		
		//Ejercicio ""
		
		System.out.print("Introduzca un numero: ");
		num1 = sc.nextInt();
		System.out.print("Introduzca un numero: ");
		num2 = sc.nextInt();
		System.out.println("El resultado de las operaciones entre "+num1+" y "+num2+" es: ");
		
		suma=suma(num1,num2);
		resta=resta(num1,num2);
		multiplicacion=multiplicacion(num1,num2);
		division=division(num1,num2);
		
		System.out.println("Suma: "+suma);
		System.out.println("Resta: "+resta);
		System.out.println("Multiplacion: "+multiplicacion);
		System.out.printf("Division: %.2f",division);
	
		
	}

}
