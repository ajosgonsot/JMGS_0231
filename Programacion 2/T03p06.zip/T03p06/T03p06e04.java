import java.util.Scanner;
public class T03p06e04 {
	
	private static int mcd(int num1, int num2){
		
		while(num1 != num2){
            if(num1>num2){
                num1= num1-num2;
			} else {
                num2= num2-num1;
			}
			
		}
		
		return num1;
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		
		int num1, num2; 
		
		//Ejercicio ""
		
		System.out.print("Introduce un numero: ");
		num1 = sc.nextInt();
		
		System.out.print("Introduce otro numero: ");
		num2 = sc.nextInt();
		
		int resultado = mcd(num1,num2);
		
		System.out.println("El MCD es: " +resultado);
    
	}

}
