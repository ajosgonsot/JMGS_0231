import java.util.Scanner;
public class T03p06e01 {
	
	public static int cifras(int numero){
		
		int contadorCifras=0;
		int cifra;
		
		while(numero!=0){
			
			cifra = numero/10;
			numero= numero/10;
			contadorCifras++;
			
		}
		
		return contadorCifras;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		 
		int numero;
		int resultado;
		
		
		//Ejercicio ""
		
		System.out.print("Introduzca un numero: ");
		numero = sc.nextInt();
		
		resultado = cifras(numero);
		
		System.out.print("El numero de cifras de "+numero+" es "+resultado);
		
		
		
		
		
	}

}
