import java.util.Scanner;
public class T03p06e02 {
	
	private static int aleatorio(int num1, int num2){
		
		int resultado;
		
		resultado = (int) (Math.random() * num2) + num1;
		
		return resultado;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		
		int nIteraciones,num1,num2,contador=0;
		double random; 
		int resultado;
		
		//Ejercicio ""
		
		System.out.print("Introduzca la cantidad de numeros aleatorios a generar: ");
		nIteraciones = sc.nextInt();
		System.out.print("Introduzca el rango minimo: ");
		num1 = sc.nextInt();
		System.out.print("Introduzca el rango maximo: ");
		num2 = sc.nextInt();
		
		
		while(contador<nIteraciones){
			resultado = aleatorio(num1,num2);
			System.out.printf("Un numero aleatorio entre 1 y 9 es: %d\n",resultado);
			contador++;
		}
		
	}

}
