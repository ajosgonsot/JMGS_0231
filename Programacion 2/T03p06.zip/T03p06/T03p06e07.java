import java.util.Scanner;
public class T03p06e07 {
	
	private static void Menu(int op){
		Scanner sc=new Scanner(System.in);
		
		System.out.println(" Menu ");
		System.out.println("------");
		System.out.println();
		System.out.println("1. Opcion A.");
		System.out.println("2. Opcion B.");
		System.out.println("3. Opcion C.");
		System.out.println();
		System.out.print("Seleccione una opcion: ");
		op = sc.nextInt();
		
		switch(op){
			case 1:
				System.out.print("La opcion seleccionada es la 1");
				break;
			case 2:
				System.out.print("La opcion seleccionada es la 2");
				break;
			case 3:
				System.out.print("La opcion seleccionada es la 3");
				break;
		}
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		 
		int op=0;
		
		//Ejercicio ""
		
		Menu(op);
		
		
	}

}
