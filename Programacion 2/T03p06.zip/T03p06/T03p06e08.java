import java.util.Scanner;
public class T03p06e08 {
	
	private static int Menu(int opcion){
		Scanner sc=new Scanner(System.in);
		
		System.out.println(" Menu ");
		System.out.println("------");
		System.out.println("");
		System.out.println("1. Opcion A");
		System.out.println("2. Opcion B");
		System.out.println("3. Opcion C");
		System.out.println("0. Salir");
		
		System.out.print("Seleccione una opcion: ");
		opcion = sc.nextInt();
		
		return opcion;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//Variables
		
		int opcion=0; 
		
		//Ejercicio ""
		
		
		do{
			opcion=Menu(opcion);
			System.out.println("");
			switch (opcion) {
			case 0:
				System.out.println("La opcion seleccionada es: 0");
				break;
			case 1:
				System.out.println("La opcion seleccionada es: 1");
				break;
			case 2:
				System.out.println("La opcion seleccionada es: 2");
				break;
			case 3:
				System.out.println("La opcion seleccionada es: 3");
				break;
			default:
				System.out.println("La opcion seleccionada no existe!!");
		
			}
			
			System.out.println("");
		
		}while(opcion!=0);	
		
	}

}
