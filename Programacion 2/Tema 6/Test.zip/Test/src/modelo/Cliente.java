package modelo;

public class Cliente {

    private String dni;         // PK
    private String nombre;
    private int edad;

    public Cliente() {
        dni = "";
        nombre = "";
        edad = 0;
    }

    public Cliente(String dni) {
        this.dni = dni;
        this.nombre = "";
        this.edad = 0;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setEdad(short edad) {
        this.edad = edad;
    }

    public void incrementarEdad(int... incremento) {
        for (int i = 0; i < incremento.length; i++) {
            edad = edad + incremento[i];
        }
    }

    public void incrementarEdad(int incremento) {
        edad = edad + incremento;
    }

    public void incrementarEdad(int incremento1, int incremento2) {
        edad = edad + incremento1 + incremento2;
    }

    public void incrementarEdad(String incremento) {
        edad = edad + Integer.parseInt(incremento);
    }

}
