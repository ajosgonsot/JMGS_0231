package test;

import modelo.Cliente;

public class Test {

////////////////////////////    private static void obtenerEjeX(Coordenada c, int[] n) {
////////////////////////////        n[0]=c.getX();
////////////////////////////    }
////////////////////////////    
////////////////////////////    private static void obtenerEjeX(Coordenada c, int n) {
////////////////////////////        n=c.getX();
////////////////////////////    }
////////////////////////////
////////////////////////////    Coordenada c=new Coordenada();
////////////////////////////    c.setCoordenada(1,2);
////////////////////////////    int x=0;
////////////////////////////    int[] xx={0};
////////////////////////////    
////////////////////////////    obtenerEjeX(c,x);
////////////////////////////    obtenerEjeX(c,xx);
////////////////////////////    
////////////////////////////    print(x)
////////////////////////////    print(xx[0])
    
    
    private static int porDos(int n) {
        n = n * 2;
        return n;
    }

    private static String concatenarHola(String s) {
        s = s + "hola";
        return s;
    }

    private static Cliente cambiarNombre(Cliente cli) {
        cli.setNombre("manolo");
        return cli;
    }

    private static void cambiarNombre2(Cliente cli) {
        cli.setNombre("manolo");
    }

    public static void main(String[] args) {

        System.out.println("");

        int x = 7;
        System.out.println(x);
        System.out.println(porDos(x));
        System.out.println(x);

        String texto = "a";
        System.out.println(texto);
        System.out.println(concatenarHola(texto));
        System.out.println(texto);

        Cliente c = new Cliente();
        Cliente c2=new Cliente("123");
        
        c.incrementarEdad(1);
        System.out.println(c.getEdad());
        
        c.setDni("1");
        c.setNombre("pepe");
        c.setEdad(20);
        System.out.printf("DNI: %s NOMBRE: %s EDAD: %d\n", c.getDni(), c.getNombre(), c.getEdad());
        cambiarNombre(c);
        System.out.printf("DNI: %s NOMBRE: %s EDAD: %d\n", c.getDni(), c.getNombre(), c.getEdad());

        System.out.println("");
    }

}
