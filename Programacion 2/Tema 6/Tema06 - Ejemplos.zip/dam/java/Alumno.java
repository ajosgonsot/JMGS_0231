package dam.java;

import java.util.*;

public class Alumno {
	
	// Atributos
	private String dni;
	private String nombre;
		
	// Constructor
	public Alumno()	{
		dni="";
		nombre="";
	}
	
	// Métodos getters&setters
	public String getDni() { return dni; }
	public String getNombre() { return nombre; }
	public void setDni(String dni) { this.dni=dni; }
	public void setNombre(String nombre) { this.nombre=nombre; }
	
	// Métodos
	
}
