/*
	Clase Holamundo
	@author yo
	@version 1.0
*/

public class Holamundo_tipos {
	
	public static void main(String[] args) {
		
		byte n1=0;				// 1 byte
		short n2=0;				// 2 bytes
		int n3=0;				// 4 bytes
		long n4=0;				// 8 bytes
		
		char c1='a';			// 2 bytes
		
		float d1=(float)0.0;	// 4 bytes
		double d2=0.0;			// 8 bytes
		
		boolean b1=true;		// 1 byte
		
		final int x=0;
		
		
		// Muestra un mensaje por pantalla
		System.out.println("Hola mundo!");
	}
	
}
