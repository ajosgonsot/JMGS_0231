/**
 * Clase Holamundo
 * @author yo
 * @version 1.0
 */
public class Holamundo {
	
	public static void main(String[] args) {
		
		/*Muestra un mensaje por pantalla*/
		System.out.println("Hola mundo!");
	}
	
}
