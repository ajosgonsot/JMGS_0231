
public class Suma {
	
	static int n1=50; //variable miembro de una clase
	
	public static void main(String[] args) {
		
		int n2=30, suma=0; //variables locales
		suma=n1+n2;
		System.out.println("La suma es: "+suma);
	}
	
}
