import java.util.Scanner;

public class T02p02e01 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define dos variables numéricas "num1" de tipo int y "num2" de tipo short.
		 * Lee un número por pantalla en la varible "num1" mayor de 32767 (no comprobar).
		 * Asigna el valor de "num1" a "num2" forzando la conversión.
		 * Muestra el nombre de las dos variables junto con sus valores por pantalla.
		 * Utiliza la función "print" o "println".
		 */
		
		int num1;
		short num2;
		
		System.out.print("Introduce un numero mayor a 32767: ");
		num1 = sc.nextInt();
		
		num2 = (short)num1;
	
		System.out.println("El valor de num1 es: " + num1);
		System.out.printf("El valor de num2 es: " + num2);
	
	}
	
}
