import java.util.Scanner;

public class T02p02e02 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define una variable "letra" de tipo char.
		 * Lee un carácter por pantalla en la variable "letra" utilizando el método next() del Scanner y cogiendo el primer carácter con la función charAt(0).
		 * Muestra el carácter leído por pantalla.
		 * Utiliza la función "print" o "println".
		 */
	
		char letra;
		
		System.out.print("Introduce una letra: ");
		letra = sc.next().charAt(0);
		
		System.out.println("La letra introducida es: " + letra);
		
	}
	
}
