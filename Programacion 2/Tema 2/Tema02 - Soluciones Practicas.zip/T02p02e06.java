import java.util.Scanner;

public class T02p02e06 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define dos variables "letraIni" y "letraFin" de tipo char.
		 * Asigna a las variables anteriores dos valores a modo de inicio y fin de un intervalo de caracteres.
		 * Define otra variable "letra" de tipo char.
		 * Lee por pantalla un carácter y asígnalo a "letra".
		 * Muestra por pantalla el texto "Dentro" o "Fuera" dependiendo si la letra leída está dentro o no del intervalo predefinido.
		 * Utiliza una variable "texto" de tipo String para guardar el texto anterior.
		 * Utiliza la función "print" o "println".
		 * Utiliza asignaciones condicionales.
		 */
	
		char letraIni = 'a';
		char letraFin = 'e';
		char letra;
		String texto;
		
		System.out.print("Introduce una letra (Intervalo " + letraIni + "," + letraFin + "): ");
		letra = sc.next().charAt(0);
		
		texto = (letra >= letraIni && letra <= letraFin) ? "Dentro" : "Fuera";
		
		System.out.println(texto);
	
	}
	
}
