import java.util.Scanner;

public class T02p02e03 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define dos variables numéricas con decimales "num1" de tipo float y "num2" de tipo double.
		 * Inicializa las variables con algún valor decimal (ojo al casting).
		 * Muestra los valores de las dos variables por pantalla.
		 * Intercambia los valores de las dos variables utilizando una varible "temporal".
		 * Muestra los nuevos valores por pantalla.
		 * Utiliza la función "print" o "println".
		 */
	
		float num1 = (float)1.5;
		double num2 = 2.5;
		double tmp;
		
		System.out.println("El valor de num1 es: " + num1 + " y el valor de num2 es: " + num2);
		
		tmp = num1;
		num1 = (float)num2;
		num2 = tmp;
		
		System.out.println("El valor de num1 es: " + num1 + " y el valor de num2 es: " + num2);
		
	}
	
}
