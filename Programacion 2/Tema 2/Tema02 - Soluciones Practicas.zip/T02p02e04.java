import java.util.Scanner;

public class T02p02e04 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define una variable "letra" de tipo char y una variable "continuar" de tipo boolean.
		 * Lee un carácter por pantalla 's' o 'n' y asígnalo a "letra".
		 * Asigna a la variable "continuar" verdadero si la letra es 's' o falso en cualquier otro caso.
		 * Muestra el mensaje "Continuando..." o "Finalizando..." por pantalla dependiendo del valor de la variable booleana.
		 * Utiliza una variable "texto" de tipo String para guardar el texto anterior.
		 * Utiliza la función "print" o "println".
		 * Utiliza asignaciones condicionales.
		 */
	
		char letra;
		boolean continuar;
		String texto;
		
		System.out.print("Introduce una letra (s/n): ");
		letra = sc.next().charAt(0);
		
		continuar = (letra=='s');
		texto = (continuar) ? "Continuando..." : "Finalizando...";
		
		System.out.println(texto);
		
	}
	
}
