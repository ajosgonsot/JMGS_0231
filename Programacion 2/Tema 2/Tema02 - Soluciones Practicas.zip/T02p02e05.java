import java.util.Scanner;

public class T02p02e05 {
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		/* Define una variable numérica "num" de tipo byte.
		 * Define un constante numérica "LIMITE" de tipo int con valor 100.
		 * Lee un número por pantalla y asígnalo a "num".
		 * Muestra la palabra "Mayor", "Igual" o "Menor" si el número leído es mayor, igual o menor al límite.
		 * Utiliza una variable "texto" de tipo String para guardar el texto anterior.
		 * Utiliza la función "print" o "println".
		 * Utiliza asignaciones condicionales.
		 */
	
		byte num;
		final int LIMITE = 100;
		String texto;
		
		System.out.print("Introduce un numero (LIMITE " + LIMITE + "): ");
		num = sc.nextByte();
		
		texto = (num>100) ? "Mayor" : ((num==100) ? "Igual" : "Menor");
		
		System.out.println(texto);
		
	}
	
}
